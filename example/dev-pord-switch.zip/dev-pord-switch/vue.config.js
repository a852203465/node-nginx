
const path = require('path');
const webpack = require('webpack');

function resolve(dir) {
    return path.resolve(__dirname, dir)
}

module.exports = {

    configureWebpack: {

        resolve: {
            alias: {
                'assets': resolve('src/assets'),
                'components': resolve('src/components'),
                'views': resolve('src/views')

            }
        },

        plugins: [

            // new webpack.DefinePlugin({
            //     'process.env': {
            //         ip: JSON.stringify(process.env.SEVER_HOST),
            //         port: JSON.stringify(process.env.SEVER_PORT),
            //         apiPrefix: JSON.stringify(process.env.API_PREFIX)
            //
            //     }
            // })


        ]
    }
};




