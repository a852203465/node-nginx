'use strict';

/**
 * 开发环境配置文件
 */
let config = {
    env: 'development', //环境名称
    serverConfig: {
        "ip": "localhost",
        "port": "8080",
        "apiPrefix": "/api",
    },
};

module.exports = config;
