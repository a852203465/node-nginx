'use strict';

/**
 * 生产环境配置文件
 */

const industryConfig = window['industry_config'] || {};
console.log('------------ industry_config -------------', industryConfig);

let config = {
    env: 'production', //环境名称
    serverConfig: industryConfig,
};

module.exports = config;
