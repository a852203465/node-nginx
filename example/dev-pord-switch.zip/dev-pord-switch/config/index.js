const configDev = require("./config.dev");
const configProd = require("./config.prod");

let env = {
    BASE_URL: '',
    ENV: '',
};

// 可以通过开发环境和生产环境系统等参数差异，判断处于哪个环境。
// const mode = process.env.OS === 'Windows_NT' ? 'env' : 'prod'

let args = process.argv.splice(2);

if (!process.env.NODE_ENV) {
    process.env.NODE_ENV = args[0];
}

// 也可以通过package.json中配置的启动命令判断处于开发还是生产环境。
if (process.env.NODE_ENV === 'dev') {
    env.ENV = configDev.env;
    env.BASE_URL = getBaseUrl(configDev.serverConfig);
} else {
    env.ENV = configProd.env;
    env.BASE_URL = getBaseUrl(configProd.serverConfig);
}

function getHost(serverConfig) {

    let ip = serverConfig.ip;
    if (!ip) ip = window.location.hostname;
    if (!/^(f|ht)tps?:\/\//i.test(ip)) {
        ip = "http://" + ip;
    }
    return ip;
}

function getPort(serverConfig) {
    return serverConfig.port ? serverConfig.port : window.location.port;
}

function getBaseUrl(serverConfig) {
    return getHost(serverConfig) + ":" + getPort(serverConfig) + getApi(serverConfig);
}

function getApi(serverConfig) {

    let apiPrefix = serverConfig.apiPrefix;
    if (apiPrefix) {
        return new RegExp("^/.*$").test(apiPrefix) ? apiPrefix : "/" + apiPrefix;
    }

    return "";
}





module.exports = env;



























